// const toggleBtn = document.getElementById('dropdownToggle');
// const dropdown = document.getElementById('treatmentsDropdown');


//   document.addEventListener('DOMContentLoaded', function () {
//     const dropdownTriggers = document.querySelectorAll('.toggle-dropdown');

//     dropdownTriggers.forEach(trigger => {
//       trigger.addEventListener('click', function (e) {
//         e.preventDefault();
//         const parent = this.parentElement;
//         const dropdown = parent.querySelector('.dropdown-content') || parent.querySelector('.sub-dropdown-content');
        
//         // Close all other open dropdowns
//         document.querySelectorAll('.dropdown-content.show, .sub-dropdown-content.show').forEach(openDropdown => {
//           if (openDropdown !== dropdown) {
//             openDropdown.classList.remove('show');
//           }
//         });


//         dropdown.classList.toggle('show');
//       });
//     });

//     document.addEventListener('click', function (e) {
//       if (!e.target.closest('.dropdown') && !e.target.closest('.sub-dropdown')) {
//         document.querySelectorAll('.dropdown-content.show, .sub-dropdown-content.show').forEach(dropdown => {
//           dropdown.classList.remove('show');
//         });
//       }
//     });
//   });


document.addEventListener('DOMContentLoaded', function () {
  const dropdownTriggers = document.querySelectorAll('.toggle-dropdown');

  dropdownTriggers.forEach(trigger => {
    trigger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();  // Important to stop bubbling up to other dropdowns

      const dropdown = this.nextElementSibling;

      // Close all dropdowns except the one being toggled
      document.querySelectorAll('.dropdown-content.show, .sub-dropdown-content.show').forEach(openDropdown => {
        if (openDropdown !== dropdown) {
          openDropdown.classList.remove('show');
        }
      });

      // Toggle current dropdown
      if (dropdown) {
        dropdown.classList.toggle('show');
      }
    });
  });

  // Close dropdowns when clicking outside
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.dropdown') && !e.target.closest('.sub-dropdown')) {
      document.querySelectorAll('.dropdown-content.show, .sub-dropdown-content.show').forEach(dropdown => {
        dropdown.classList.remove('show');
      });
    }
  });
});
