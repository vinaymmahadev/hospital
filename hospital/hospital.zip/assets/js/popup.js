
  function openPopup() {
    document.getElementById('popup').style.display = 'flex';
  }

  function closePopup() {
    document.getElementById('popup').style.display = 'none';
  }



function showPrivacyPolicy() {
  document.getElementById('privacyPopup').style.display = 'flex';
}

function closePrivacyPolicy() {
  document.getElementById('privacyPopup').style.display = 'none';
}




function handleSearch() {
  const searchTerm = document.getElementById('search-input').value.trim();
  if (!searchTerm) {
    alert('Please enter a search term');
    return;
  }

  // Clear previous highlights
  clearHighlights();

  // Search and highlight
  const content = document.getElementById('content') || document.body;
  const regex = new RegExp(searchTerm, 'gi');
  let firstMatch = null;

  function highlightText(node) {
    if (node.nodeType === 3) { // text node
      const match = node.data.match(regex);
      if (match) {
        const span = document.createElement('span');
        span.className = 'highlight';
        const frag = document.createDocumentFragment();

        let lastIndex = 0;
        node.data.replace(regex, (m, i) => {
          // Add text before match
          const before = node.data.slice(lastIndex, i);
          if (before) frag.appendChild(document.createTextNode(before));

          // Add highlighted match
          const mark = document.createElement('span');
          mark.textContent = m;
          mark.className = 'highlight';
          frag.appendChild(mark);

          if (!firstMatch) firstMatch = mark;

          lastIndex = i + m.length;
        });

        // Add remaining text after last match
        const after = node.data.slice(lastIndex);
        if (after) frag.appendChild(document.createTextNode(after));

        node.parentNode.replaceChild(frag, node);
      }
    } else if (node.nodeType === 1 && node.childNodes && !['SCRIPT','STYLE'].includes(node.tagName)) {
      // recursively process child nodes, but skip script/style tags
      for (let i = 0; i < node.childNodes.length; i++) {
        highlightText(node.childNodes[i]);
      }
    }
  }

  highlightText(content);

  if (firstMatch) {
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
    firstMatch.style.backgroundColor = 'yellow';  // Additional highlight
  } else {
    alert('No matches found');
  }
}

function clearHighlights() {
  const highlights = document.querySelectorAll('.highlight');
  highlights.forEach(el => {
    const parent = el.parentNode;
    parent.replaceChild(document.createTextNode(el.textContent), el);
    parent.normalize(); // merge adjacent text nodes
  });
}

