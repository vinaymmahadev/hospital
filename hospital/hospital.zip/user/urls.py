from django.urls import path
from .views import Home,Bookingpop,ScanView,FissureView,PilesView,BookingView,PrivacyView,Term_conditionView,AushmanView,AboutView

urlpatterns = [

    path('',Home.as_view(),name='home'),
    path('book_pop/',Bookingpop.as_view(),name='book_pop'),
    path('scan/',ScanView.as_view(),name='scan'),
    path('fissure/',FissureView.as_view(),name='fissure'),
    path('piles/',PilesView.as_view(),name='piles'),
    path('submit-booking/',BookingView.as_view(),name='submit-booking'),
    path('privacyview/',PrivacyView.as_view(),name='privacyview'),
    path('Term_condition/',Term_conditionView.as_view(),name='Term_condition'),
    path('aushman/',AushmanView.as_view(),name='aushman'),
    path('about/',AboutView.as_view(),name='about'),


]
