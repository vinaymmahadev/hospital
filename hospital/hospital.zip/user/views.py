from django.shortcuts import render
from django.views import View    
import json
import os
import openpyxl
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from .models import Booking


class Home(View):
    def get(self, request):
        return render(request,"home.html")

class Bookingpop(View):
    def get(self, request):
        return render(request,"booknow.html")

class ScanView(View):
    def get(self,request):
        return render(request,"scan.html")
    

class FissureView(View):
    def get(self,request):
        return render(request,"fissure.html")
    
class PilesView(View):
    def get(self,request):
        return render(request,"piles.html")
    
class PrivacyView(View):
    def get(self,request):
        return render(request,"privacy&policy.html")    
    
class Term_conditionView(View):
    def get(self,request):
        return render(request,"terms&conditions.html")
    
class AushmanView(View):
    def get(self,request):
        return render(request,"aushman.html")
    
class AboutView(View):
    def get(self,request):
        return render(request,"about.html")


@method_decorator(csrf_exempt, name='dispatch')
class BookingView(View):
    def post(self, request):
        try:
            data = json.loads(request.body)
            name = data.get('name')
            phone = data.get('phone_number')
            location = data.get('location')
            treatment = data.get('treatment')

            # Save booking to database
            Booking.objects.create(
                name=name,
                phone_number=phone,
                location=location,
                treatment=treatment
            )

            return JsonResponse({'message': 'Booking saved!'}, status=201)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)